#include<stdio.h>
#include<Math.h>
#include<limits.h>

int max(int a[], int n){
    int max=INT_MIN;
    int index = 0;
    for(int i=0;i<n;i++){
        if(max<a[i]){
            max = a[i];
            index = i;
        }
    }
    return index;
}

int min(int a[], int n, int k){
    int min=INT_MAX;
    int index=0;
    for(int i=n;i>=k;i--){
        if(min>a[i]){
            min = a[i];
            index = i;
        }
    }
    return index;
}

void balance(int a[], int n, int k){
    int high =  max(a, k);
    int low = min(a, n, k);
    if(a[high]>a[low]){
        int temp = a[low];
        a[low] = a[high];
        a[high] = temp;
        balance(a,n,k);
    }
}

void main(){
    int n,k;
    printf("Enter no. of elements in array : ");
    scanf("%d",&n);
    int a[n];
    printf("Enter array elements : ");
    for(int i=0;i<n;i++)
        scanf("%d",&a[i]);
    printf("Enter value of k : ");
    scanf("%d",&k);
    balance(a, n, k);
    printf("Output array : ");
    for(int i=0;i<n;i++)
        printf("%d ",a[i]);
}