#include <stdio.h>
void swap(float i, float j){
    float temp;
    temp = i;
    i = j;
    j = temp;
    printf("%.2f %.2f", i, j);
}
int main(){
    float i, j;
    printf("Please enter the space seperated numbers to be swapped");
    scanf("%f %f", &i, &j);
    swap(i, j);
    return 0;
    
}