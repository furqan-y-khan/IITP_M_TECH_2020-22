/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
static int total_nodes;
void printValues(int A[], int size){
   //printf("The subset is:");
   for (int i = 0; i < size; i++) {
      printf("%*d", 5, A[i]);
   }
   printf("\n");
   
}
void subset_sum(int s[], int t[], int s_size, int t_size, int sum, int ite, int const target_sum){
   total_nodes++;
   if (target_sum == sum) {
      printValues(t, t_size);
      subset_sum(s, t, s_size, t_size - 1, sum - s[ite], ite + 1, target_sum);
      return;
   }
   else {
      for (int i = ite; i < s_size; i++) {
         t[t_size] = s[i];
         subset_sum(s, t, s_size, t_size + 1, sum + s[i], i + 1, target_sum);
      }
   }
}
void generateSubsets(int s[], int size, int target_sum){
   int* tuplet_vector = (int*)malloc(size * sizeof(int));
   subset_sum(s, tuplet_vector, size, 0, 0, 0, target_sum);
   free(tuplet_vector);
}
int main(){
    int entries, sum = 0;
    printf("Enter the number of entries you want in a set: ");
    scanf("%d", &entries);
    int set[entries];
    // taking input and storing it in an array
    for(int i = 0; i < entries; ++i) {
        scanf("%d", &set[i]);
    }
	printf("Enter the required sum: ");
	scanf("%d", &sum);
    int size = sizeof(set) / sizeof(set[0]);
    printf("The set is ");
    printValues(set , size);
    generateSubsets(set, size, sum);
    if (101 == sum){
        printf("Error! Sum not found");
    }
    //printf("Total Nodes generated %d\n", total_nodes);
    return 0;
}
